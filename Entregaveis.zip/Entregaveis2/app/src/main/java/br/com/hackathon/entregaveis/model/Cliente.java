package br.com.hackathon.entregaveis.model;

import android.support.annotation.NonNull;

import java.io.Serializable;

public class Cliente implements Serializable {

    private int id = 0;
    private String nome;
    private String telefone;
    private String email;
    private String documento;

    public Cliente(String nome, String telefone, String email, String documento) {
        this.nome = nome;
        this.telefone = telefone;
        this.email = email;
        this.documento = documento;
    }

    public Cliente() {
    }

    public Cliente(String fran, String s, String s1) {

    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setDocumento(String documento) {
        this.documento = documento;
    }

    public String getNome() {
            return nome;
    }

    public String getTelefone() {
        return telefone;
    }

    public String getEmail() {
        return email;
    }

    public String getDocumento() {
        return documento;
    }

    @NonNull
    @Override
    public String toString() {
        return nome;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId() {
        return id;
    }

    public boolean temIdValido() {
        return id > 0;
    }

    public void remove(Cliente cliente) {

    }
}
