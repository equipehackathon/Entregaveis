package br.com.hackathon.entregaveis.ui.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import br.com.hackathon.entregaveis.R;
import br.com.hackathon.entregaveis.model.Cliente;

class ListaClienteAdapter extends BaseAdapter {

    private final List<Cliente> cliente = new ArrayList<>();
    private final Context context;

    public ListaClienteAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return cliente.size();
    }

    @Override
    public Cliente getItem(int posicao) {
        return cliente.get(posicao);
    }

    @Override
    public long getItemId(int posicao) {
        return cliente.get(posicao).getId();
    }

    @Override
    public View getView(int posicao, View view, ViewGroup viewGroup) {
        View viewCriada = criaView(viewGroup);
        Cliente clienteDevolvido = cliente.get(posicao);
        vincula(viewCriada, clienteDevolvido);
        return viewCriada;
    }

    private void vincula(View view, Cliente cliente) {
        TextView nome = view.findViewById(R.id.item_cliente_nome);
        nome.setText(cliente.getNome());
        TextView telefone = view.findViewById(R.id.item_cliente_telefone);
        telefone.setText(cliente.getTelefone());
    }

    private View criaView(ViewGroup viewGroup) {
        return LayoutInflater
                .from(context)
                .inflate(R.layout.item_cliente, viewGroup, false);
    }

    public void atualiza(List<Cliente> cliente){
        this.cliente.clear();
        this.cliente.addAll(cliente);
        notifyDataSetChanged();
    }

    public void remove(Cliente cliente) {
        cliente.remove(cliente);
        notifyDataSetChanged();
    }
}
