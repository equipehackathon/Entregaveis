package br.com.hackathon.entregaveis.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;

import br.com.hackathon.entregaveis.R;
import br.com.hackathon.entregaveis.dao.ClienteDAO;
import br.com.hackathon.entregaveis.model.Cliente;

import static br.com.hackathon.entregaveis.ui.activity.ConstantesActivities.CHAVE_CLIENTE;

public class FormularioClienteActivity extends AppCompatActivity {

    private static final String TITULO_APPBAR_NOVO_CLIENTE = "Novo cliente";
    private static final String TITULO_APPBAR_EDITA_CLIENTE = "Edita cliente";
    private static final String CHAVE_CLIENTE = "CHAVE_CLIENTE";
    private EditText campoNome;
    private EditText campoTelefone;
    private EditText campoEmail;
    private  EditText campoDocumento;
    private final ClienteDAO dao = new ClienteDAO();
    private Cliente cliente;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario_cliente);
        inicializacaoDosCampos();
        carregaCliente();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater()
                .inflate(R.menu.activity_formulario_cliente_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int itemId = item.getItemId();
        if(itemId == R.id.activity_formulario_cliente_menu_salvar){
            finalizaFormulario();
        }
        return super.onOptionsItemSelected(item);
    }

    private void carregaCliente() {
        Intent dados = getIntent();
        if (dados.hasExtra(CHAVE_CLIENTE)) {
            setTitle(TITULO_APPBAR_EDITA_CLIENTE);
            cliente = (Cliente) dados.getSerializableExtra(CHAVE_CLIENTE);
            preencheCampos();
        } else {
            setTitle(TITULO_APPBAR_NOVO_CLIENTE);
            cliente = new Cliente();
        }
    }

    private void preencheCampos() {
        campoNome.setText(cliente.getNome());
        campoTelefone.setText(cliente.getTelefone());
        campoEmail.setText(cliente.getEmail());
        campoDocumento.setText(cliente.getDocumento());
    }

    private void finalizaFormulario() {
        preencheCliente();
        if (cliente.temIdValido()) {
            dao.edita(cliente);
        } else {
            dao.salva(cliente);
        }
        finish();
    }

    private void preencheCliente() {

    }

    private void inicializacaoDosCampos() {
        campoNome = findViewById(R.id.activity_formulario_cliente_nome);
        campoTelefone = findViewById(R.id.activity_formulario_cliente_telefone);
        campoEmail = findViewById(R.id.activity_formulario_cliente_email);
        campoDocumento = findViewById(R.id.activity_formulario_cliente_documento);
    }

}
