package br.com.hackathon.entregaveis.ui.activity;

public interface ConstantesActivities {
    String CHAVE_CLIENTE = "cliente";
}
