package br.com.hackathon.entregaveis;

import android.app.Application;

import br.com.hackathon.entregaveis.dao.ClienteDAO;
import br.com.hackathon.entregaveis.model.Cliente;


@SuppressWarnings("WeakerAccess")
public class RCA extends Application {
    @Override
     public void onCreate() {
        super.onCreate();
        criaClienteTeste();
        }

     private void criaClienteTeste() {
        ClienteDAO dao = new ClienteDAO();
        dao.salva(new Cliente("Alex", "1122223333", "alex@gmai.com.br"));
        dao.salva(new Cliente("Fran", "1122223333", "fran@gmail.com"));
    }
}

