package br.com.hackathon.entregaveis;

public class landingpage {
}
