package br.com.hackathon.entregaveis.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.List;

import br.com.hackathon.entregaveis.R;
import br.com.hackathon.entregaveis.dao.ClienteDAO;
import br.com.hackathon.entregaveis.model.Cliente;

import static br.com.hackathon.entregaveis.ui.activity.ConstantesActivities.CHAVE_CLIENTE;

public class ListaClienteActivity extends AppCompatActivity {

    public static final String TITULO_APPBAR = "Lista de clientes";
    private final ClienteDAO dao = new ClienteDAO();
    private ArrayAdapter<Cliente> adapter;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_cliente);
        setTitle(TITULO_APPBAR);
        configuraFabNovoCliente();
        configuraLista();
        dao.salva(new Cliente("Alex", "1122223333", "alex@gmail.com.br"));
        dao.salva(new Cliente("Fran", "1122223333", "fran@gmail.com"));
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        getMenuInflater()
                .inflate(R.menu.activity_lista_cliente_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {

        int itemId = item.getItemId();
        if (itemId == R.id.activity_lista_cliente_menu_remover) {
            AdapterView.AdapterContextMenuInfo menuInfo =
                    (AdapterView.AdapterContextMenuInfo) item.getMenuInfo();
            Cliente clienteEscolhido = adapter.getItem(menuInfo.position);
            remove(clienteEscolhido);
        }

        return super.onContextItemSelected(item);
    }

    private void configuraFabNovoCliente() {
        FloatingActionButton botaoNovoCliente = findViewById(R.id.activity_lista_cliente_fab_novo_cliente);
        botaoNovoCliente.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abreFormularioModoInsereCliente();
            }
        });
    }

    private void abreFormularioModoInsereCliente() {
        startActivity(new Intent(this, FormularioClienteActivity.class));
    }

    @Override
    protected void onResume() {
        super.onResume();
        atualizaCliente();
    }

    private void atualizaCliente() {
        adapter.clear();
        adapter.addAll(dao.todos());
    }

    private void configuraLista() {
        ListView listaDeCliente = findViewById(R.id.activity_lista_cliente_listview);
        configuraAdapter(listaDeCliente);
        configuraListenerDeCliquePorItem(listaDeCliente);
        registerForContextMenu(listaDeCliente);
    }

    private void remove(Cliente cliente) {
        dao.remove(cliente);
        adapter.remove(cliente);
    }

    private void configuraListenerDeCliquePorItem(ListView listaDeCliente) {
        listaDeCliente.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int posicao, long id) {
                Cliente clienteEscolhido = (Cliente) adapterView.getItemAtPosition(posicao);
                abreFormularioModoEditaCliente(clienteEscolhido);
            }
        });
    }

    private void abreFormularioModoEditaCliente(Cliente cliente) {
        Intent vaiParaFormularioActivity = new Intent(ListaClienteActivity.this, FormularioClienteActivity.class);
        vaiParaFormularioActivity.putExtra(CHAVE_CLIENTE, cliente);
        startActivity(vaiParaFormularioActivity);
    }

    private void configuraAdapter(ListView listaDeCliente) {
        adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1);
        listaDeCliente.setAdapter(adapter);
    }
}
