package br.com.hackathon.entregaveis;

import android.view.View;

public class LandingPageActivity {
 LandingPage landingpage = ( landingpage ) findViewById ( R . Id . Button_send );
 botão . setOnClickListener ( new View. OnClickListener () {
  public void onClick ( View.generateViewId() ) {  } });


 }
