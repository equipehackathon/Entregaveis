package br.com.hackathon.entregaveis.dao;

import android.support.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import br.com.hackathon.entregaveis.model.Cliente;

public class ClienteDAO {

    private final static List<Cliente> cliente = new ArrayList<>();
    private static int contadorDeIds = 1;

    public void salva(Cliente cliente) {
        cliente.setId(contadorDeIds);
        cliente.add(cliente);
        atualizaIds();
    }

    private void atualizaIds() {
        contadorDeIds++;
    }

    public void edita(Cliente cliente) {
        Cliente clienteEncontrado = buscaClientePeloId(cliente);
        if (clienteEncontrado != null) {
            int posicaoDoCliente = cliente.indexOf(clienteEncontrado);
            cliente.set(posicaoDoCliente, cliente);
        }
    }

    @Nullable
    private Cliente buscaClientePeloId(Cliente cliente) {
        for (Cliente a :
                cliente) {
            if (a.getId() == cliente.getId()) {
                return a;
            }
        }
        return null;
    }

    public List<Cliente> todos() {
        return new ArrayList<>(cliente);
    }

    public void remove(Cliente cliente) {
        Cliente clienteDevolvido = buscaClientePeloId(cliente);
        if(clienteDevolvido != null){
            cliente.remove(clienteDevolvido);
        }
    }
}
}
